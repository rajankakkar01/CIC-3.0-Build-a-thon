from flask import Flask, jsonify, render_template, request
import random 
import json
import pickle
import numpy as np
import tensorflow as tf
import nltk
from nltk.stem import WordNetLemmatizer
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout

# Initialize Flask app
app = Flask(__name__)

lemmatizer = WordNetLemmatizer()

intents = json.loads(open('intents.json').read())

# Load the saved model
model = tf.keras.models.load_model("chatbot.h5")

# Load the preprocessed data
words = pickle.load(open('words.pkl', 'rb'))
classes = pickle.load(open('classes.pkl', 'rb'))

# Define functions for message processing and response prediction
def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence.lower())
    sentence_words = [lemmatizer.lemmatize(word) for word in sentence_words]
    return sentence_words

def bag_of_words(sentence):
    sentence_words = clean_up_sentence(sentence)
    bag = [0] * len(words)
    for w in sentence_words:
        for i, word in enumerate(words):
            if word == w:
                bag[i] = 1
    return np.array(bag)

def predict_class(sentence):
    bow = bag_of_words(sentence)
    res = model.predict(np.array([bow]))[0]

    error_threshold = 0.25
    results = [[i, r] for i, r in enumerate(res) if r > error_threshold]
    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []
    for r in results:
        return_list.append({'intent': classes[r[0]], 'probability': str(r[1])})
    return return_list

def get_response(intents_list, intents_json):
    if intents_list:
        tag = intents_list[0]['intent']
        list_of_intents = intents_json['intents']
        for i in list_of_intents:
            if i['tag'] == tag:
                result = random.choice(i['responses'])
                return result
    # If intents_list is empty or if the tag is not found, return a default response
    return "I'm sorry, I don't understand that."


# Main route for rendering the chat interface
@app.route('/')
def home():
    return render_template('index.html')

# Flask route modifications
@app.route('/chat', methods=['POST'])
def chat():
    # Process user input
    message = request.json['message']
    
    # Predict response
    intents_list = predict_class(message)
    res = get_response(intents_list, intents)
    
    # Return response
    return jsonify({'response': res})


if __name__ == '__main__':
    app.run(debug=True)
